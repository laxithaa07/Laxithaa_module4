# React Task 4 – Student Portal

A clean and responsive React + Vite project demonstrating:

- Functional React components
- `useState` for login state and marks
- Props between parent and child components
- Controlled login form
- Conditional rendering
- Responsive CSS
- Simple marks increment/decrement controls

## Demo Login

- **Username:** `admin`
- **Password:** `1234`

## Project Structure

```text
React-Task-4-Laxithaa/
├── public/
├── src/
│   ├── components/
│   │   ├── Marks.jsx
│   │   └── Student.jsx
│   ├── App.css
│   ├── App.jsx
│   ├── Login.jsx
│   ├── Students.jsx
│   ├── index.css
│   └── main.jsx
├── .gitignore
├── index.html
├── package.json
├── README.md
└── vite.config.js
```

## Run Locally

```bash
npm install
npm run dev
```

## Production Build

```bash
npm run build
```
