import { useState } from 'react'

function Login({ onLogin }) {
  const [username, setUsername] = useState('')
  const [password, setPassword] = useState('')
  const [error, setError] = useState('')

  const handleSubmit = (event) => {
    event.preventDefault()

    if (username.trim() === 'admin' && password === '1234') {
      setError('')
      onLogin()
      return
    }

    setError('Invalid username or password. Use admin / 1234 for the demo.')
  }

  return (
    <main className="login-page">
      <section className="login-card" aria-labelledby="login-title">
        <div className="brand-icon" aria-hidden="true">🎓</div>
        <p className="eyebrow">REACT TASK 4</p>
        <h1 id="login-title">Student Portal</h1>
        <p className="subtitle">Sign in to view the student profile and marks.</p>

        <form onSubmit={handleSubmit} className="login-form">
          <label htmlFor="username">Username</label>
          <input
            id="username"
            type="text"
            value={username}
            onChange={(event) => setUsername(event.target.value)}
            placeholder="Enter username"
            autoComplete="username"
            required
          />

          <label htmlFor="password">Password</label>
          <input
            id="password"
            type="password"
            value={password}
            onChange={(event) => setPassword(event.target.value)}
            placeholder="Enter password"
            autoComplete="current-password"
            required
          />

          {error && <p className="error-message" role="alert">{error}</p>}

          <button className="primary-button" type="submit">Login</button>
        </form>

        <div className="demo-note">
          <strong>Demo login</strong>
          <span>Username: admin</span>
          <span>Password: 1234</span>
        </div>
      </section>
    </main>
  )
}

export default Login
