import Student from './components/Student.jsx'
import Marks from './components/Marks.jsx'

function Students({ onLogout }) {
  return (
    <main className="students-page">
      <header className="dashboard-header">
        <div>
          <p className="eyebrow">REACT TASK 4</p>
          <h1>Student Dashboard</h1>
          <p className="dashboard-subtitle">Manage profile information and marks using React components and state.</p>
        </div>
        <button className="logout-button" type="button" onClick={onLogout}>Logout</button>
      </header>

      <section className="dashboard-grid" aria-label="Student information">
        <Student
          name="G. Laxithaa"
          rollNo="111424243033"
          course="B.Tech Artificial Intelligence & Data Science"
          college="Prathyusha Engineering College"
        />
        <Marks subject="React" initialMarks={85} />
      </section>

      <footer className="footer-note">Built with React + Vite • React Task 4</footer>
    </main>
  )
}

export default Students
