function Student({ name, rollNo, course, college }) {
  return (
    <article className="info-card">
      <div className="card-heading">
        <span className="card-icon" aria-hidden="true">👤</span>
        <div>
          <p className="card-label">PROFILE</p>
          <h2>Student Profile</h2>
        </div>
      </div>

      <dl className="details-list">
        <div><dt>Name</dt><dd>{name}</dd></div>
        <div><dt>Register Number</dt><dd>{rollNo}</dd></div>
        <div><dt>Course</dt><dd>{course}</dd></div>
        <div><dt>College</dt><dd>{college}</dd></div>
      </dl>
    </article>
  )
}

export default Student
