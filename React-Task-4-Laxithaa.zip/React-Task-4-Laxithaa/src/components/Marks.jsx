import { useState } from 'react'

function Marks({ subject, initialMarks }) {
  const [marks, setMarks] = useState(initialMarks)

  const addMark = () => setMarks((current) => Math.min(100, current + 1))
  const removeMark = () => setMarks((current) => Math.max(0, current - 1))

  return (
    <article className="info-card marks-card">
      <div className="card-heading">
        <span className="card-icon" aria-hidden="true">📊</span>
        <div>
          <p className="card-label">RESULT</p>
          <h2>Student Marks</h2>
        </div>
      </div>

      <div className="subject-row">
        <span>Subject</span>
        <strong>{subject}</strong>
      </div>

      <div className="marks-display" aria-live="polite">
        <span>{marks}</span>
        <small>/ 100</small>
      </div>

      <div className="progress-track" aria-label={`Marks: ${marks} out of 100`}>
        <div className="progress-fill" style={{ width: `${marks}%` }} />
      </div>

      <div className="marks-actions">
        <button className="secondary-button" type="button" onClick={removeMark} disabled={marks === 0}>
          − Remove Mark
        </button>
        <button className="primary-button" type="button" onClick={addMark} disabled={marks === 100}>
          + Add Mark
        </button>
      </div>
    </article>
  )
}

export default Marks
